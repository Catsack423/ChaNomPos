<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Ingredient;
use App\Models\Product;
use App\Models\Recipe;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;

class MenuController extends Controller
{
    public function adminMenu()
    {
        // 1. ดึงข้อมูลสินค้าพร้อมสูตรและสต็อก (Eager Loading เพื่อลด N+1 Query)
        $allProducts = Product::with('recipes.ingredient.inventory', 'categories')->get();

        $toActivate = [];
        $toDeactivate = [];

        foreach ($allProducts as $product) {
            // ตั้งต้นให้เป็น true: ถ้าไม่มีสูตรเลย (isEmpty) จะถือว่า Active ได้ทันที
            $canMake = true;

            // ถ้ามีสูตร ให้ตรวจสอบสต็อก
            if (!$product->recipes->isEmpty()) {
                foreach ($product->recipes as $recipe) {
                    // กรณีข้อมูลวัตถุดิบหรือสต็อกหายไป ให้ถือว่าทำไม่ได้
                    if (!$recipe->ingredient || !$recipe->ingredient->inventory) {
                        $canMake = false;
                        break;
                    }

                    // ถ้าสต็อกมีน้อยกว่าที่สูตรระบุ
                    if ($recipe->ingredient->inventory->quantity < $recipe->amount) {
                        $canMake = false;
                        break;
                    }
                }
            }

            // เก็บ ID สินค้าที่ต้องเปลี่ยนสถานะ เพื่ออัปเดตทีเดียว (Optimization)
            if ($canMake && !$product->is_active) {
                $toActivate[] = $product->id;
            } elseif (!$canMake && $product->is_active) {
                $toDeactivate[] = $product->id;
            }
        }

        // อัปเดตสถานะแบบ Bulk (ยิง Query แค่ 1-2 ครั้ง แทนการยิงใน Loop)
        if (!empty($toActivate)) {
            Product::whereIn('id', $toActivate)->update(['is_active' => 1]);
        }
        if (!empty($toDeactivate)) {
            Product::whereIn('id', $toDeactivate)->update(['is_active' => 0]);
        }

        // 2. ดึงข้อมูลใหม่หลังจากอัปเดตแล้วเพื่อส่งไป View
        $products = Product::with(['recipes.ingredient', 'categories'])->get();
        $ingredients = Ingredient::with('recipe')->get();
        $categories = Category::all();

        return view('page.adminmenu', compact('products', 'ingredients', 'categories'));
    }

    public function activate($id)
    {
        // หาข้อมูลสินค้า
        $product = Product::findOrFail($id);

        // ตั้งค่าให้แสดงผล (is_show = 1)
        $product->is_show = 1;
        $product->save();

        return redirect()->back()->with('success', "เปิดการแสดงผล '{$product->name}' สำเร็จ");
    }

    public function toggle(Product $product)
    {
        try {
            // สลับค่า is_show
            $product->is_show = !$product->is_show;
            $product->save();

            $statusText = $product->is_show ? 'แสดง' : 'ซ่อน';

            return response()->json([
                'status' => 'success',
                'message' => "ทำการ {$statusText} เมนู '{$product->name}' เรียบร้อยแล้ว",
                'is_show' => $product->is_show
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => 'เกิดข้อผิดพลาด: ' . $e->getMessage()
            ], 500);
        }
    }

    // ================= โหมดสร้างสินค้า (Create) =================
    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => 'required',
            'price' => 'required|numeric',
            'description' => 'required',
            'image' => 'nullable|image',
            'category_ids' => 'nullable|array',
            'ingredients' => 'nullable|array',
            'amounts' => 'nullable|array',
        ]);

        // ตั้งค่ารูปภาพเริ่มต้น
        $data['imgurl'] = 'img/default.png';

        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $filename = time() . '_' . $file->getClientOriginalName();
            $file->move(public_path('img'), $filename);
            $data['imgurl'] = 'img/' . $filename;
        }

        // 1. สร้างสินค้า
        $product = Product::create($data);

        // 2. ซิงค์ประเภทสินค้า
        if ($request->has('category_ids')) {
            $product->categories()->sync($request->category_ids);
        }

        // 3. บันทึกสูตรสินค้า
        if ($request->has('ingredients') && $request->has('amounts')) {
            foreach ($request->ingredients as $index => $ingredient_id) {
                if (!empty($ingredient_id) && !empty($request->amounts[$index])) {
                    $product->recipes()->create([
                        'ingredient_id' => $ingredient_id,
                        'amount' => $request->amounts[$index]
                    ]);
                }
            }
        }

        return redirect()->route('adminmenu')->with('success', 'เพิ่มเมนูเรียบร้อยแล้ว');
    }

    // ================= โหมดแก้ไขสินค้า (Update) =================
    public function update(Request $request, $id)
    {
        $product = Product::findOrFail($id);

        $data = $request->validate([
            'name' => 'required',
            'price' => 'required|numeric',
            'description' => 'required',
            'image' => 'nullable|image',
            'category_ids' => 'nullable|array',
            'ingredients' => 'nullable|array',
            'amounts' => 'nullable|array',
        ]);

        // จัดการรูปภาพ (ถ้ามีการอัปโหลดใหม่)
        if ($request->hasFile('image')) {

            // ป้องกันการลบรูปที่สินค้าอื่นใช้แชร์อยู่ (Fix รูปพัง)
            if ($product->imgurl && $product->imgurl !== 'img/default.png') {
                $isImageShared = Product::where('imgurl', $product->imgurl)
                    ->where('id', '!=', $product->id)
                    ->exists();

                // ถ้าเช็คแล้ว "ไม่มี" สินค้าอื่นใช้รูปนี้อยู่ ถึงจะอนุญาตให้ลบไฟล์เก่าทิ้ง
                if (!$isImageShared && File::exists(public_path($product->imgurl))) {
                    File::delete(public_path($product->imgurl));
                }
            }

            // อัปโหลดรูปใหม่
            $file = $request->file('image');
            $filename = time() . '_' . $file->getClientOriginalName();
            $file->move(public_path('img'), $filename);
            $data['imgurl'] = 'img/' . $filename;
        }

        // 1. อัปเดตข้อมูลพื้นฐาน
        $product->update($data);

        // 2. ซิงค์ประเภทสินค้า (อันไหนไม่ถูกติ๊กจะถูกถอดออกอัตโนมัติ)
        $product->categories()->sync($request->category_ids ?? []);

        // 3. อัปเดตสูตร (ลบของเดิมทิ้งให้หมด แล้วใส่เข้าไปใหม่ตามที่ส่งมา)
        $product->recipes()->delete();
        if ($request->has('ingredients') && $request->has('amounts')) {
            foreach ($request->ingredients as $index => $ingredient_id) {
                if (!empty($ingredient_id) && !empty($request->amounts[$index])) {
                    $product->recipes()->create([
                        'ingredient_id' => $ingredient_id,
                        'amount' => $request->amounts[$index]
                    ]);
                }
            }
        }

        return redirect()->back()->with('success', 'อัปเดตเมนูเรียบร้อยแล้ว');
    }

    // ================= โหมดลบสินค้า (Destroy) =================
    public function destroy($id)
    {
        $product = Product::findOrFail($id);

        // ป้องกันลบไฟล์รูปภาพที่มีสินค้าตัวอื่นใช้อยู่ (Fix รูปพัง)
        if ($product->imgurl && $product->imgurl !== 'img/default.png') {
            $isImageShared = Product::where('imgurl', $product->imgurl)
                ->where('id', '!=', $product->id)
                ->exists();

            // ถ้าเช็คแล้วไม่มีใครใช้ ค่อยลบทิ้ง
            if (!$isImageShared && File::exists(public_path($product->imgurl))) {
                File::delete(public_path($product->imgurl));
            }
        }

        $product->delete();
        return redirect()->back()->with('success', 'ลบเมนูสำเร็จ');
    }

    // ================= AJAX Categories =================
    public function ajaxStoreCategory(Request $request)
    {
        $request->validate(['name' => 'required|string|max:255']);
        $category = Category::create(['name' => $request->name]);
        return response()->json(['success' => true, 'category' => $category]);
    }

    public function ajaxDeleteCategory($id)
    {
        $category = Category::findOrFail($id);
        $category->delete();
        return response()->json(['success' => true]);
    }
}
